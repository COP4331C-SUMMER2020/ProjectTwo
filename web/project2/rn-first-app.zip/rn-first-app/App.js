import { StatusBar } from 'expo-status-bar';
import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { Button } from 'react-native';

export default function App() {

	const BASE_URL = 'https://COP4331-3.herokuapp.com/';

	const testMe = async event => 
    {

		var js = '{"login":'
            + '"RickL"'
            + ',"password":'
            + '"COP4331"' +'}';
			
        try
        {    
            const response = await fetch(BASE_URL + 'api/login',
                {method:'POST',body:js,headers:{'Content-Type': 'application/json'}});

            var res = JSON.parse(await response.text());
			
			alert(res.firstName + ' ' + res.lastName );
        }
        catch(e)
        {
            alert(e.toString());
            return;
        }    


	}

  return (
    <View style={styles.container}>
      <Text>Open up App.js to start working on your app!</Text>
	<Button
          title="Press me"
          onPress={testMe}
        />
      <StatusBar style="auto" />
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
});
